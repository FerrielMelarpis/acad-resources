#include "structures.h"
#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

Queue *createQueue(){
  Queue *q = malloc(sizeof(Queue));
  q->next = NULL;
  return q;
}

Machine *createMachine(){
  Machine *m = malloc(sizeof(Machine));
  m->head = m->tail = createQueue();
  return m;
}

void enqueue(Machine *m, int x){
  m->tail->next = createQueue();
  m->tail->next->x = x;
  m->tail = m->tail->next;
}

int dequeue(Machine *m){
  if(m->head->next==NULL){
    return -1;
  }
  Queue *tmp = m->head->next;
  m->head->next = m->head->next->next;
  int x = tmp->x;
  free(tmp);
  return x;
}

int getSum(Machine *m){
  int sum=0;
  Queue *tmp = m->head->next;
  while(tmp!=NULL){
    sum+=tmp->x;
    tmp = tmp->next;
  }
  return sum;
}

int getIndex(Machine **m, int x){
  int i, sum, min=10000, index;
  for(i=0;i<x;i++){
    sum = getSum(m[i]);
    if(sum<min){
      min = sum;
      index = i;
    }
  }
  return index;
}

void terminate(Machine *m){
  Queue *tmp;
  while(m->head->next!=NULL){
    tmp = m->head->next;
    m->head->next = m->head->next->next;
    free(tmp);
  }
  free(m->head);
  free(m);
}