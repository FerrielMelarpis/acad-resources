/*
 * (C)  Ferriel Lisandro B. Melarpis
 * 	2012-01065
 * 	CAS BSCS 
 * 	CMSC123 CD-2L
 * 	University of the Philippines Los Banos
 * 	"This is a program that implements the algorithm for job scheduling"
 */
// libraries
#include <stdio.h> // for standard input and output functions
#include <stdlib.h> // for memory allocation functions
#include "files.h" // for functions use in files
#include "queue.h" // for functions use in implementing queues
#include "structures.h" // for the structures used by the program
// main
int main(void){
  Machine *main = createMachine();
  Machine **m;
  int n, x, size = input(main, &m);
  if(size==-1){ 
    fprintf(stderr,"FILE NOT FOUND\n");
  }else{
    while((n=dequeue(main))!=-1){
      x = getIndex(m, size);
      enqueue(m[x], n);
    }
    output(m, size);
  }
  int i;
  for(i=0;i<size;i++){
    terminate(m[i]);
  }
  terminate(main);
  return 0;
}