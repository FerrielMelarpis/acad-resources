#ifndef FILES_H
#define FILES_H
#include "structures.h"
#include <stdio.h>

void output(Machine **, int); // function that prints the job schedule in a text file
void mOutput(FILE *, Machine *); // function that prints the list of jobs in a machine
int input(Machine *, Machine ***);// function that scans a text file for input in the program

#endif// FILES_H