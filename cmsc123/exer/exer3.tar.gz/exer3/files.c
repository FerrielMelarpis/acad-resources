#include "files.h"
#include "queue.h"
#include "structures.h"
#include <stdio.h>
#include <stdlib.h>

void mOutput(FILE *fp, Machine *m){
  Queue *tmp=m->head->next;
  while(tmp!=NULL){
    fprintf(fp,"%3d",tmp->x);
    tmp=tmp->next;
  }fputc('\n', fp);
}

void output(Machine **m, int size){
  FILE *fp=fopen("output.txt","w");
  int i;
  for(i=0;i<size;i++){
    fprintf(fp,"Machine %d:", i+1);
    mOutput(fp, m[i]);
  }
  fclose(fp);
}

int input(Machine *main, Machine ***m){
  FILE *fp=fopen("input.txt","r");
  int x, i;
  if(!fp){
    return -1;
  }else{
    do{
      fscanf(fp,"%d", &x);
      enqueue(main, x);
    }while(fgetc(fp)!='\n');
    fscanf(fp,"%d", &x);
    *m = malloc(sizeof(Machine)*x);
    for(i=0;i<x;i++){
      *(*m+i)=createMachine();
    }
  }
  fclose(fp);
  return x;
}