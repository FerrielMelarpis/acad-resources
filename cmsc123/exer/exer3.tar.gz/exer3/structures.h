#ifndef STRUCTURE_H
#define STRUCTURE_H

typedef struct node_tag Queue;
typedef struct list_tag Machine;
struct node_tag{
  int x;
  Queue *next;
};
struct list_tag{
  Queue *head;
  Queue *tail;
};

#endif// STRUCTURE_H