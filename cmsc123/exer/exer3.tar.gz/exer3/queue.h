#ifndef QUEUE_H
#define QUEUE_H

Queue *createQueue(); // function that creates structure for queue
Machine *createMachine(); // function that creates structure for machine
void enqueue(Machine *, int); // function that appends a job in a queue on a machine
int dequeue(Machine *); // function that deletes a job in a queue on a machine
int getSum(Machine *); // function that returns the total time of a machine
int getIndex(Machine **, int); // function that returns the index of available machine
void terminate(Machine *); // function that deallocates all the pointers used in the program

#endif// QUEUE_H