<?php
	session_start();
	
	if($_SESSION["login"] != 1){
		header("Location: login.php");
		exit;
	}
?>

<html>
<head>
<title></title>
</head>
<body>
	<a href = "logout.php">Log out</a>
</body>
</html>
	
