<?php
echo $_COOKIE["user"];

print_r($_COOKIE);
?>
