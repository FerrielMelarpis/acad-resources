<?php
setcookie("user", "Maverick Crisostomo", time()+3600);
setcookie("id", "44730", time()+3600);
?>

<html>
<head></head>
<body></body>
</html>
