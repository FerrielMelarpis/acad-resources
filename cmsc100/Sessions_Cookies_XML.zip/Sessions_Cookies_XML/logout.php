<?php
	session_start();
	session_destroy();
?>
<html>
<head>
<title></title>
</head>
<body>
<p> User Logged Out</p>
</body>
</html>
