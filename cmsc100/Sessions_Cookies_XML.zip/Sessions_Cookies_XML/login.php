<?php
session_start();

if(isset($_POST["submit"])){
	if($_POST["username"]=='admin' && $_POST["password"]=='admin1234'){
		$_SESSION["login"] = 1;
		header("Location: submit.php");
		exit;
	}else{
		echo "Wrong details";

	}
}
?>

<html>
	<head>
		<title></title>
	</head>
	<body>
		<form action="login.php" method="POST">
			Username: <input type="text" name="username" /><br />
			Password: <input type="text" name="password" /><br />
			<input type="submit" name="submit" value="Login" />
		</form>
	</body>
</html>

