<?php session_start(); 
	if(isset($_SESSION["views"]))
		$_SESSION["views"]=$_SESSION["views"]+1;
	else
		$_SESSION["views"] = 1;
?>

<html>
<head>
	<title></title>
</head>
<body>
<?php echo "Pageviews=". $_SESSION["views"]; ?>
</body>
</html>
